package com.tsk.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeTestApplication.class, args);
	}

}
